#include <stdio.h>
#include <stdlib.h>
#include "pic16.h"
#include "hardware.h"
#include "lcd_4bit.h"

int contador=0;

//fun��o principal
void main(void)
{
    //inicializa e configura LCD
    init_lcd_4bit();
    __delay_ms(100);

    //tela de boas vindas
    lcd_escreve_s("\f   BEM  VINDO\n................");
    __delay_ms(2000);

    //la�o principal
    while(1)
    {
        lcd_escreve_p("\f%i \nCONTADOR: %i", 12345, contador);
        contador++;
        __delay_ms(1000);
    }
}

