// File:   lcd_4bit.h
// Author: User

#ifndef LCD_4BIT_H
#define	LCD_4BIT_H

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "hardware.h"
#include "pic16.h"

//pinos display
#define TR_DADO_4  TRISDbits.TRISD4
#define TR_DADO_5  TRISDbits.TRISD5
#define TR_DADO_6  TRISDbits.TRISD6
#define TR_DADO_7  TRISDbits.TRISD7
#define TR_ENABLE  TRISEbits.TRISE1
#define TR_RS      TRISEbits.TRISE0
#define LCD_DADO_4 PORTDbits.RD4
#define LCD_DADO_5 PORTDbits.RD5
#define LCD_DADO_6 PORTDbits.RD6
#define LCD_DADO_7 PORTDbits.RD7
#define LCD_ENABLE PORTEbits.RE1
#define LCD_RS     PORTEbits.RE0

#define lcd_type 2        // 0=5�7, 1=5�10, 2=2 lines
#define lcd_line_two 0x40 // LCD RAM address for the 2nd line

const unsigned char LCD_INIT_STRING[4]=
{
    20 | (lcd_type << 2),   // Func set: 4-bit, 2 lines, 5�8 dots
    0xc,                    // liga display
    1,                      // limpa display
    6                       // incrementa cursor
};

void init_lcd_4bit(void);
void lcd_envia_nibble(unsigned char n);
void lcd_envia_byte(unsigned char address, unsigned char n);
void lcd_gotoxy(unsigned char x, unsigned char y);
void lcd_putc(unsigned char c);
void lcd_escreve_p(const unsigned char *n, ...);
void lcd_escreve_s(const unsigned char *y);

#endif	/* LCD_4BIT_H */

